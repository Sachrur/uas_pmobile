// ip disini menyesuaikan ip dari device masing masing *api/v1 -> prefix versioning api
// ignore_for_file: constant_identifier_names

const String BASE_URL = 'http://192.168.1.7:3500/api/v1';
